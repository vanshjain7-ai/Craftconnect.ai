// Application data
const appData = {
  "artisans": [
    {
      "id": "artisan_001",
      "name": "Meera Sharma",
      "location": "Jaipur, Rajasthan",
      "craft": "Block Printing",
      "heritage": "Third-generation block printer carrying forward 200-year-old family tradition",
      "image": "https://images.unsplash.com/photo-1594736797933-d0401ba4ba1b?w=300",
      "products": ["prod_001", "prod_002"]
    },
    {
      "id": "artisan_002", 
      "name": "Ravi Kumar",
      "location": "Varanasi, Uttar Pradesh",
      "craft": "Silk Weaving",
      "heritage": "Master weaver specializing in Banarasi silk sarees using traditional handloom techniques",
      "image": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
      "products": ["prod_003", "prod_004"]
    },
    {
      "id": "artisan_003",
      "name": "Lakshmi Devi",
      "location": "Channapatna, Karnataka", 
      "craft": "Wooden Toys",
      "heritage": "Eco-friendly toy maker using 400-year-old lacquer turning technique",
      "image": "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300",
      "products": ["prod_005", "prod_006"]
    }
  ],
  "products": [
    {
      "id": "prod_001",
      "name": "Indigo Block Print Bedsheet",
      "artisan_id": "artisan_001",
      "price": 2500,
      "image": "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400",
      "category": "Home Textiles",
      "basic_description": "Hand block printed bedsheet with indigo dye",
      "ai_story": "This exquisite bedsheet tells the story of ancient Rajasthani craftsmanship, where indigo - once more valuable than gold - meets the rhythmic dance of hand-carved teak blocks. Meera's great-grandmother first learned this art during the British Raj, when natural indigo from Gujarat fields created the signature deep blue that adorns royal palaces. Each geometric pattern carved into century-old wooden blocks carries symbolic meaning - the paisley represents fertility, while the intricate borders ward off negative energy. The 16-step process begins before dawn, as Meera prepares the natural mordants that will make the indigo bond with organic cotton threads, creating a textile that grows more beautiful with each wash, just as this timeless craft grows richer with each generation.",
      "cultural_significance": "Indigo dyeing represents prosperity and protection in Rajasthani culture",
      "process_steps": ["Hand-carving teak blocks", "Preparing natural indigo dye", "16-layer printing process", "Natural sun-drying"],
      "customizable": true
    },
    {
      "id": "prod_002",
      "name": "Rajasthani Wall Hanging",
      "artisan_id": "artisan_001", 
      "price": 1800,
      "image": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
      "category": "Wall Art",
      "basic_description": "Traditional wall hanging with mirror work",
      "ai_story": "In the golden sands of Rajasthan, where every sunset paints the desert in hues of amber and crimson, this wall hanging captures the soul of nomadic artistry. The tiny mirrors, each no bigger than a fingernail, are hand-stitched using a technique called 'shisha embroidery' - a craft that traveling caravan families developed to reflect moonlight and guide lost travelers home. Meera learned this intricate art from her grandmother, who would spend entire summers under the shade of neem trees, teaching young girls how each mirror must catch light differently to create the mesmerizing shimmer that makes these pieces come alive.",
      "cultural_significance": "Mirror work believed to bring positive energy and ward off evil eye",
      "process_steps": ["Natural fabric dyeing", "Hand-cutting mirrors", "Traditional shisha embroidery", "Decorative finishing"],
      "customizable": true
    },
    {
      "id": "prod_003",
      "name": "Banarasi Silk Saree",
      "artisan_id": "artisan_002",
      "price": 15000,
      "image": "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400", 
      "category": "Traditional Wear",
      "basic_description": "Pure silk saree with gold zari work",
      "ai_story": "From the ghats of Varanasi, where the Ganges reflects ancient temple spires, comes this masterpiece of textile artistry that has adorned queens and goddesses for over 500 years. Ravi's family has woven dreams into silk since the Mughal era, when Persian craftsmen brought their intricate designs to the banks of the sacred river. This saree requires six months to complete on a traditional handloom - each golden thread of zari is real metallic wire wrapped around silk core, creating patterns inspired by Mughal architecture, blooming lotus flowers, and celestial motifs.",
      "cultural_significance": "Considered auspicious for weddings and religious ceremonies",
      "process_steps": ["Silk thread preparation", "Zari thread wiring", "6-month handloom weaving", "Traditional finishing"],
      "customizable": false
    },
    {
      "id": "prod_004", 
      "name": "Brocade Table Runner",
      "artisan_id": "artisan_002",
      "price": 3500,
      "image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400",
      "category": "Home Decor",
      "basic_description": "Silk brocade table runner with traditional motifs",
      "ai_story": "This elegant table runner brings the grandeur of Mughal courts to modern dining spaces, where every meal becomes a royal feast. Woven on the same traditional looms that once created fabrics for emperors, this piece showcases the sophisticated artistry of Varanasi's brocade tradition. The intricate paisley motifs, known as 'kalka,' represent the mango - a symbol of life and fertility in Indian culture.",
      "cultural_significance": "Brocade patterns symbolize prosperity and abundance",
      "process_steps": ["Natural silk dyeing", "Metallic thread preparation", "Kadhua weaving technique", "Hand-finished edges"],
      "customizable": true
    },
    {
      "id": "prod_005",
      "name": "Channapatna Wooden Elephant",
      "artisan_id": "artisan_003",
      "price": 800,
      "image": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
      "category": "Toys & Decor",
      "basic_description": "Hand-carved wooden elephant toy with natural lacquer",
      "ai_story": "In the quaint town of Channapatna, where the scent of sandalwood mingles with the whir of traditional lathes, Lakshmi transforms ordinary ivory wood into magical creatures that have delighted children for four centuries. This charming elephant, carved from a single piece of sustainably sourced hale wood, follows a technique introduced by Tipu Sultan in the 18th century when he brought Persian craftsmen to establish this eco-friendly toy industry.",
      "cultural_significance": "Elephants symbolize wisdom, strength, and good fortune",
      "process_steps": ["Sustainable wood selection", "Hand-lathe carving", "Natural lacquer application", "Hand-polishing finish"],
      "customizable": true
    },
    {
      "id": "prod_006",
      "name": "Wooden Train Set",
      "artisan_id": "artisan_003", 
      "price": 1200,
      "image": "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400",
      "category": "Toys & Games",
      "basic_description": "Handcrafted wooden train set with multiple cars",
      "ai_story": "All aboard the imagination express! This delightful train set carries the legacy of Channapatna's toy-making tradition, where generations of families have created joy from simple blocks of wood. Lakshmi carves each train car with the precision of a master sculptor, using techniques passed down through five generations of her family.",
      "cultural_significance": "Trains represent journey, progress, and connection between communities",
      "process_steps": ["Individual car carving", "Traditional joint crafting", "Multi-colored lacquer work", "Child-safety finishing"],
      "customizable": true
    }
  ],
  "live_shopping_session": {
    "artisan": "Meera Sharma",
    "product": "Custom Block Print Kurta",
    "viewers": 23,
    "chat_messages": [
      {"user": "Sarah_NY", "message": "Can you make this in blue instead of red?", "timestamp": "14:32"},
      {"user": "ArtLover_Mumbai", "message": "What natural dyes do you use?", "timestamp": "14:33"},
      {"user": "CraftEnthusiast", "message": "How long does the dyeing process take?", "timestamp": "14:34"}
    ],
    "customization_options": [
      "Color variation",
      "Pattern density", 
      "Size adjustment",
      "Border design"
    ]
  }
};

// Global variables
let currentProducts = [...appData.products];
let chatMessageCount = 0;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    renderProducts();
    setupEventListeners();
    initializeLiveChat();
    setupNavigation();
}

// Setup navigation functionality - Fixed version
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // Scroll to section
            const targetId = this.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });
}

// Fixed scroll to section utility
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const offsetTop = section.offsetTop - 80; // Account for fixed navbar
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
        
        // Update active navigation
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${sectionId}`) {
                link.classList.add('active');
            }
        });
    }
}

// Fixed setup event listeners
function setupEventListeners() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }
    if (categoryFilter) {
        categoryFilter.addEventListener('change', handleSearch);
    }
}

// Product rendering
function renderProducts() {
    const productGrid = document.getElementById('productGrid');
    if (!productGrid) return;
    
    productGrid.innerHTML = '';
    
    currentProducts.forEach(product => {
        const artisan = appData.artisans.find(a => a.id === product.artisan_id);
        const productCard = createProductCard(product, artisan);
        productGrid.appendChild(productCard);
    });
}

function createProductCard(product, artisan) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => openProductModal(product);
    
    card.innerHTML = `
        <img src="${product.image}" alt="${product.name}" class="product-image">
        <div class="product-info">
            <h3>${product.name}</h3>
            <div class="product-price">₹${product.price.toLocaleString()}</div>
            <div class="artisan-name">by ${artisan.name}, ${artisan.location}</div>
            <div class="cultural-tag">${product.cultural_significance}</div>
        </div>
    `;
    
    return card;
}

// Fixed search and filter functionality
function handleSearch() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    
    if (!searchInput || !categoryFilter) return;
    
    const searchTerm = searchInput.value.toLowerCase();
    const selectedCategory = categoryFilter.value;
    
    currentProducts = appData.products.filter(product => {
        const artisan = appData.artisans.find(a => a.id === product.artisan_id);
        
        const matchesSearch = !searchTerm || 
            product.name.toLowerCase().includes(searchTerm) ||
            artisan.name.toLowerCase().includes(searchTerm) ||
            artisan.location.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm);
            
        const matchesCategory = !selectedCategory || product.category === selectedCategory;
        
        return matchesSearch && matchesCategory;
    });
    
    renderProducts();
}

// Product modal functionality
function openProductModal(product) {
    const artisan = appData.artisans.find(a => a.id === product.artisan_id);
    const modal = document.getElementById('productModal');
    
    if (!modal) return;
    
    // Populate modal content
    const elements = {
        modalTitle: document.getElementById('modalTitle'),
        modalImage: document.getElementById('modalImage'),
        modalArtisanImage: document.getElementById('modalArtisanImage'),
        modalArtisanName: document.getElementById('modalArtisanName'),
        modalArtisanLocation: document.getElementById('modalArtisanLocation'),
        modalArtisanHeritage: document.getElementById('modalArtisanHeritage'),
        modalPrice: document.getElementById('modalPrice'),
        modalCulturalSignificance: document.getElementById('modalCulturalSignificance'),
        modalStory: document.getElementById('modalStory'),
        modalProcess: document.getElementById('modalProcess')
    };
    
    if (elements.modalTitle) elements.modalTitle.textContent = product.name;
    if (elements.modalImage) {
        elements.modalImage.src = product.image;
        elements.modalImage.alt = product.name;
    }
    if (elements.modalArtisanImage) elements.modalArtisanImage.src = artisan.image;
    if (elements.modalArtisanName) elements.modalArtisanName.textContent = artisan.name;
    if (elements.modalArtisanLocation) elements.modalArtisanLocation.textContent = `${artisan.craft} • ${artisan.location}`;
    if (elements.modalArtisanHeritage) elements.modalArtisanHeritage.textContent = artisan.heritage;
    if (elements.modalPrice) elements.modalPrice.textContent = `₹${product.price.toLocaleString()}`;
    if (elements.modalCulturalSignificance) elements.modalCulturalSignificance.textContent = product.cultural_significance;
    if (elements.modalStory) elements.modalStory.textContent = product.ai_story;
    
    // Populate process steps
    if (elements.modalProcess) {
        elements.modalProcess.innerHTML = '';
        product.process_steps.forEach(step => {
            const li = document.createElement('li');
            li.textContent = step;
            elements.modalProcess.appendChild(li);
        });
    }
    
    modal.classList.remove('hidden');
}

function closeModal() {
    const modal = document.getElementById('productModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

// Fixed AI Story Generation
function generateAIStory() {
    const elements = {
        productName: document.getElementById('productName'),
        category: document.getElementById('productCategory'),
        location: document.getElementById('artisanLocation'),
        basicDescription: document.getElementById('basicDescription')
    };
    
    if (!elements.productName || !elements.category || !elements.location || !elements.basicDescription) {
        alert('Form elements not found');
        return;
    }
    
    const productName = elements.productName.value;
    const category = elements.category.value;
    const location = elements.location.value;
    const basicDescription = elements.basicDescription.value;
    
    if (!productName || !category || !location || !basicDescription) {
        alert('Please fill in all fields to generate an AI story.');
        return;
    }
    
    // Show loading state
    const generateBtn = event.target;
    const originalText = generateBtn.textContent;
    generateBtn.textContent = 'Generating AI Story...';
    generateBtn.disabled = true;
    
    // Simulate AI processing delay
    setTimeout(() => {
        const aiStory = generateAIStoryText(productName, category, location, basicDescription);
        showAIStoryResult(basicDescription, aiStory);
        
        // Reset button
        generateBtn.textContent = originalText;
        generateBtn.disabled = false;
    }, 2000);
}

function generateAIStoryText(productName, category, location, basicDescription) {
    const locationParts = location.split(',');
    const city = locationParts[0]?.trim() || 'ancient lands';
    const state = locationParts[1]?.trim() || 'India';
    
    const templates = [
        `In the vibrant heart of ${city}, where centuries-old traditions dance with modern creativity, this exquisite ${productName.toLowerCase()} tells a story that transcends time. Master craftsmen in ${state} have perfected this art form through generations, where each piece carries the soul of its creator and the wisdom of ancestral techniques. The intricate process begins at dawn, when artisans gather the finest materials sourced from local communities, ensuring that every thread, every stroke, every detail reflects the cultural heritage that makes ${state} a treasure trove of Indian craftsmanship. This ${category.toLowerCase()} is not merely a product - it's a bridge connecting the past with the present, carrying forward traditions that have enriched Indian culture for millennia.`,
        
        `From the bustling workshops of ${city} emerges this magnificent ${productName.toLowerCase()}, a testament to the unwavering dedication of ${state}'s master artisans. Each piece begins as a vision, inspired by the rich tapestry of local folklore, natural landscapes, and spiritual traditions that define this remarkable region. The craftsperson's skilled hands transform raw materials into works of art using techniques passed down through family lineages, where secrets of the trade are whispered from master to apprentice under the same roof where great-grandparents once practiced their craft. This ${category.toLowerCase()} embodies the essence of sustainable luxury - where traditional methods meet contemporary needs, creating pieces that grow more beautiful with time and use.`,
        
        `Nestled in the cultural heartland of ${city}, this stunning ${productName.toLowerCase()} carries within it the dreams and aspirations of generations of artisans who have called ${state} home. The creation process is a meditation in itself, where time slows down and each movement becomes deliberate and meaningful. Local materials, harvested with respect for nature's bounty, are transformed through age-old techniques that honor both the environment and the ancestors who perfected these methods. This ${category.toLowerCase()} represents more than craftsmanship - it's a celebration of community spirit, where neighbors support each other's artistic endeavors, and where every purchase helps preserve invaluable cultural traditions for future generations.`
    ];
    
    const randomTemplate = templates[Math.floor(Math.random() * templates.length)];
    return randomTemplate;
}

function showAIStoryResult(basicDescription, aiStory) {
    const resultSection = document.getElementById('aiStoryResult');
    const beforeText = document.getElementById('beforeText');
    const afterText = document.getElementById('afterText');
    
    if (!resultSection || !beforeText || !afterText) return;
    
    beforeText.textContent = basicDescription;
    afterText.textContent = aiStory;
    
    resultSection.style.display = 'block';
    resultSection.scrollIntoView({ behavior: 'smooth' });
}

// Fixed Live Chat functionality
function initializeLiveChat() {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    // Load initial chat messages
    appData.live_shopping_session.chat_messages.forEach(message => {
        addChatMessage(message.user, message.message, message.timestamp);
    });
    
    // Setup chat input
    const chatInput = document.getElementById('chatInput');
    if (chatInput) {
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendChatMessage();
            }
        });
    }
    
    // Simulate new messages periodically
    setInterval(simulateIncomingMessage, 15000);
}

function addChatMessage(username, message, timestamp = null) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message';
    
    const currentTime = timestamp || new Date().toLocaleTimeString('en-US', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    messageDiv.innerHTML = `<strong>${username}:</strong> ${message} <small>(${currentTime})</small>`;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    if (!chatInput) return;
    
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Add user message
    addChatMessage('You', message);
    chatInput.value = '';
    
    // Simulate artisan response after a delay
    setTimeout(() => {
        const responses = [
            "Thank you for your interest! Yes, I can definitely customize that for you.",
            "That's a great question! Let me show you the process in detail.",
            "I use only natural, eco-friendly materials sourced locally.",
            "Each piece takes about 2-3 days to complete with personal attention.",
            "I'd be happy to create a custom piece in your preferred colors!"
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        addChatMessage('Meera Sharma', randomResponse);
    }, 1500);
}

function simulateIncomingMessage() {
    const messages = [
        { user: 'CraftCollector_Delhi', message: 'This is absolutely beautiful! How much for international shipping?' },
        { user: 'TraditionalLover', message: 'My grandmother had similar patterns. This brings back memories!' },
        { user: 'SustainableStyle', message: 'Love that you use natural dyes. Do you have other eco-friendly options?' },
        { user: 'ArtStudent_Pune', message: 'Could you explain more about the block carving process?' },
        { user: 'HeritageHunter', message: 'Are these designs inspired by historical patterns?' }
    ];
    
    if (chatMessageCount < 5) { // Limit automated messages
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        addChatMessage(randomMessage.user, randomMessage.message);
        chatMessageCount++;
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('productModal');
    if (modal && event.target === modal) {
        closeModal();
    }
});